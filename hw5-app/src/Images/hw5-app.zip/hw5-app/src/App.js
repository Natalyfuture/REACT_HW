import './App.css';
import {YourCards} from './Components/YourCards';
import {CardForm} from './Components/CardForm';
import {useState} from "react";


function App() {
    // const [newCard, setNewCard] = useState([]);


    return (
        <div className="App">
            {/*<YourCards/>*/}
            {/*<CardForm setNewCard={setNewCard} newCard={newCard}/>*/}
        </div>
    );
}

export default App;
