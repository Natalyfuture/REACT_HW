import React, {useEffect, useState} from 'react';
import {MyCard} from './CreateCard';
import '../App.css'

export const YourCards = ({cards}) => {
    const renderCard = (cardData, user_name) => {
        return (
            <div key={cardData.id}>
                <MyCard
                    numberCard={cardData.card.numbers}
                    fullName={user_name}
                    logo={cardData.card.type}
                    id={cardData.id}
                    dataValid={cardData.card.expiry_date}
                    cvv={cardData.card.cvv}
                    dataStatistic={cardData.statistic}
                />
            </div>
        );
    }


    if (cards.length === 0) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            {
                cards.map(({user_name, data}) => {
                    // неправильный вид обьекта data, у возвращаемых с сервера внутри лежит обьект типа {id: 1, card: {…}, statistic: Array(3)}
                    // а внутри card обьект вида {numbers: '4041593714000350', type: 'visa', expiry_date: '6/30/2021', cvv: 293}
                    // так же из-за неправильных названий полей в React возникает ошибка

                    // проверьте комментарии в CardForm.js и измените вид и поля обьекта, соответсвующие тем, которые передаются в MyCard.js

                    return data.map((cardData) => (
                        renderCard(cardData, user_name)
                    ))
                })
            }
        </div>
    )

}

